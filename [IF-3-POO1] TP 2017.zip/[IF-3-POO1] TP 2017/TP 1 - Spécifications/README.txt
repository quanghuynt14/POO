RAPPEL : LE PLAGIAT EST INTERDIT PAR LA LOI.
IL EST INTERDIT DE COPIER-COLLER / RECOPIER MOT POUR MOT TOUT OU UNE PARTIE DU CONTENU DE CETTE ARCHIVE (CODE OU COMPTE-RENDUS).

Ces documents mis � votre disposition par d'anciens 3IF ont pour vocation de vous aider � comprendre plus concr�tement ce qui est attendu de vous par les profs de 3IF en TP/TD. L'objectif est de vous donner un petit coup de pouce technique avec une approche "par l'exemple" (architecture logicielle, techniques algorithmiques...), mais le travail et la COMPREHENSION DE CE QUE VOUS CONCEVEZ ET IMPLEMENTEZ doit venir de VOUS.

Il ne s'agit en aucun cas d'une correction, et ces rendus sont tout � fait perfectibles (mais soyez rassur�s, ils ont re�u de bonnes notes).

Bonnes r�visions !
Un 4IF bienveillant.